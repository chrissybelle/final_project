export { default } from "./Edamam.js";
